import numpy as np 

X_train_1 = np.random.randint(0, 10, size=(30000, 10))

X_test_1 = np.random.randint(0, 10, size=(100, 10))

y_train_1 = np.array([1 if np.sqrt((X_train_1*X_train_1).sum(axis=1))[i]>=15 else 0 for i in range(0, 30000)]) 
y_test_1 = np.array([1 if np.sqrt((X_test_1*X_test_1).sum(axis=1))[i]>=15 else 0 for i in range(0, 100)])

np.savetxt("X_train_1.csv", X_train_1, delimiter=",")

np.savetxt("X_test_1.csv", X_test_1, delimiter=",")

np.savetxt("y_train_1.csv", y_train_1, delimiter=",")

np.savetxt("y_test_1.csv", y_test_1, delimiter=",")










