import numpy as np 

ND = np.random.randint(0, 10, size=(100, 10))

ND_distance = np.sqrt((ND*ND).sum(axis=1))

np.savetxt("ND.csv", ND, delimiter=",")

np.savetxt("ND_distance.csv", ND_distance, delimiter=",")










