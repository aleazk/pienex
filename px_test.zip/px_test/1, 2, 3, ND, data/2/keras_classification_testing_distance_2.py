import numpy as np 

ND, ND_distance = np.loadtxt("ND.csv", delimiter=","), np.loadtxt("ND_distance.csv", delimiter=",")



import keras 



from keras.models import load_model

pretrained_model = load_model("2.h5")

predictions = pretrained_model.predict(ND[10:20])

print (predictions)

print (ND_distance[10:20])