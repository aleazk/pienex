import numpy as np 

X_train_2 = np.random.randint(0, 10, size=(30000, 10))

X_test_2 = np.random.randint(0, 10, size=(100, 10))

y_train_2 = np.array([1 if np.sqrt((X_train_2*X_train_2).sum(axis=1))[i]<16 else 0 for i in range(0, 30000)]) 
y_test_2 = np.array([1 if np.sqrt((X_test_2*X_test_2).sum(axis=1))[i]<16 else 0 for i in range(0, 100)])

np.savetxt("X_train_2.csv", X_train_2, delimiter=",")

np.savetxt("X_test_2.csv", X_test_2, delimiter=",")

np.savetxt("y_train_2.csv", y_train_2, delimiter=",")

np.savetxt("y_test_2.csv", y_test_2, delimiter=",")










