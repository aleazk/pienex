import numpy as np 

X_train_3 = np.random.randint(0, 10, size=(30000, 10))

X_test_3 = np.random.randint(0, 10, size=(100, 10))

y_train_3 = np.array([1 if int (np.sqrt((X_train_3*X_train_3).sum(axis=1))[i])==15 else 0 for i in range(0, 30000)]) 
y_test_3 = np.array([1 if int (np.sqrt((X_train_3*X_train_3).sum(axis=1))[i])==15 else 0 for i in range(0, 100)])

np.savetxt("X_train_3.csv", X_train_3, delimiter=",")

np.savetxt("X_test_3.csv", X_test_3, delimiter=",")

np.savetxt("y_train_3.csv", y_train_3, delimiter=",")

np.savetxt("y_test_3.csv", y_test_3, delimiter=",")










