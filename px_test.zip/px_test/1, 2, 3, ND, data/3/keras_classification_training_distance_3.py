import numpy as np 

import keras 

from keras.models import Sequential
from keras.layers import Dense
from keras.utils import to_categorical

X_train_3, y_train_3 = np.loadtxt("X_train_3.csv", delimiter=","), np.loadtxt("y_train_3.csv", delimiter=",")

X_test_3, y_test_3 = np.loadtxt("X_test_3.csv", delimiter=","), np.loadtxt("y_test_3.csv", delimiter=",")


num = X_train_3.shape[1]

y_train_3 = to_categorical(y_train_3)
y_test_3 = to_categorical(y_test_3)
num_classes = y_test_3.shape[1]

def classification_model():
	model = Sequential()
	model.add(Dense(num, activation="relu", input_shape=(num,)))
	model.add(Dense(100, activation="relu"))
	model.add(Dense(num_classes, activation="softmax"))
	model.layers[1]._name = "dense_1"
	model.compile(optimizer="adam", loss="categorical_crossentropy", metrics=["accuracy"])
	return model

model = classification_model()

model.fit(X_train_3, y_train_3, validation_data=(X_test_3, y_test_3), epochs=100, verbose=2)

scores = model.evaluate(X_test_3, y_test_3, verbose=0)

print ("Accuracy: {}%\n Error: {}".format(scores[1], 1 - scores[1]))

model.save("3.h5")


