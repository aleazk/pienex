import pienex as px

r = px.reasoning ( ((1, 1, 2), 4, 3) )

#r.programme()

#ndpredictions = r.ndpredict("ND")

#print (ndpredictions[70:80])

import numpy as np

ND_distance = np.loadtxt("ND_distance.csv", delimiter=",")

r_0 = px.reasoning((1, 1, 2))

ndpredictions_0 = r_0.ndpredict("ND")

print (ndpredictions_0[20:30])

print (ND_distance[20:30])